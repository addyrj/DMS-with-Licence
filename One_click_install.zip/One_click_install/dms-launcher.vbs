Set oShell = CreateObject("Shell.Application")
oShell.ShellExecute "powershell.exe", "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & "
C:\Users\Dell\Desktop\dms\dms\One_click_install
\setup-prod.ps1" & """", "
C:\Users\Dell\Desktop\dms\dms\One_click_install
", "runas", 1
