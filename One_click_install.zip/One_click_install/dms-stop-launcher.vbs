Set oShell = CreateObject("Shell.Application")
oShell.ShellExecute "powershell.exe", "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command ""taskkill /f /im node.exe & taskkill /f /im mosquitto.exe & taskkill /f /im httpd.exe & taskkill /f /im mysqld.exe""", "", "runas", 1
