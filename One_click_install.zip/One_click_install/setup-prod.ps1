# DMS Production Mode
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$ROOT     = (Get-Item "$PSScriptRoot\..").FullName
$BACKEND  = "$ROOT\backend"
$FRONTEND = "$ROOT\dms-frontend"

function Kill-Port($port) {
    $lines = netstat -ano | Select-String ":$port "
    foreach ($line in $lines) {
        $pid2 = ($line -split "\s+")[-1]
        if ($pid2 -match "^\d+$" -and [int]$pid2 -gt 0) {
            Stop-Process -Id ([int]$pid2) -Force -ErrorAction SilentlyContinue
        }
    }
}

function Create-Shortcuts {
    $startSC = "$env:USERPROFILE\Desktop\DMS Start.lnk"
    $stopSC  = "$env:USERPROFILE\Desktop\DMS Stop.lnk"
    $iconDir = "$PSScriptRoot\icons"
    $shell   = New-Object -ComObject WScript.Shell

    $launcherPath = "$PSScriptRoot\dms-launcher.vbs"
    $launcherLines = @(
        'Set oShell = CreateObject("Shell.Application")',
        'oShell.ShellExecute "powershell.exe", "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & "' + $PSScriptRoot + '\setup-prod.ps1" & """", "' + $PSScriptRoot + '", "runas", 1'
    )
    [System.IO.File]::WriteAllLines($launcherPath, $launcherLines, [System.Text.Encoding]::ASCII)

    $stopLauncherPath = "$PSScriptRoot\dms-stop-launcher.vbs"
    $stopLauncherLines = @(
        'Set oShell = CreateObject("Shell.Application")',
        'oShell.ShellExecute "powershell.exe", "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command ""taskkill /f /im node.exe & taskkill /f /im mosquitto.exe & taskkill /f /im httpd.exe & taskkill /f /im mysqld.exe""", "", "runas", 1'
    )
    [System.IO.File]::WriteAllLines($stopLauncherPath, $stopLauncherLines, [System.Text.Encoding]::ASCII)

    $lnk = $shell.CreateShortcut($startSC)
    $lnk.TargetPath       = "wscript.exe"
    $lnk.Arguments        = "`"$launcherPath`""
    $lnk.WorkingDirectory = $PSScriptRoot
    $lnk.WindowStyle      = 1
    $lnk.Description      = "Start DMS Digital Signage"
    if (Test-Path "$iconDir\dms-start.ico") { $lnk.IconLocation = "$iconDir\dms-start.ico" }
    $lnk.Save()

    $lnk2 = $shell.CreateShortcut($stopSC)
    $lnk2.TargetPath       = "wscript.exe"
    $lnk2.Arguments        = "`"$stopLauncherPath`""
    $lnk2.WorkingDirectory = $PSScriptRoot
    $lnk2.WindowStyle      = 1
    $lnk2.Description      = "Stop DMS Digital Signage"
    if (Test-Path "$iconDir\dms-stop.ico") { $lnk2.IconLocation = "$iconDir\dms-stop.ico" }
    $lnk2.Save()
}

function Wait-ForApp {
    Write-Host "    Waiting for DMS to be ready..." -ForegroundColor Yellow
    $backendReady  = $false
    $frontendReady = $false
    for ($i = 1; $i -le 40; $i++) {
        Start-Sleep 3
        if (-not $backendReady) {
            try {
                Invoke-WebRequest -Uri "http://localhost:5004" -UseBasicParsing -TimeoutSec 2 -ErrorAction Stop | Out-Null
                $backendReady = $true
            } catch {
                if ($_.Exception.Response -ne $null) {
                    $backendReady = $true
                }
            }
        }
        if (-not $frontendReady) {
            try {
                Invoke-WebRequest -Uri "http://localhost:3000" -UseBasicParsing -TimeoutSec 2 -ErrorAction Stop | Out-Null
                $frontendReady = $true
            } catch {
                if ($_.Exception.Response -ne $null) {
                    $frontendReady = $true
                }
            }
        }
        if ($backendReady -and $frontendReady) {
            Write-Host "[OK] DMS is ready - opening browser now" -ForegroundColor Green
            Start-Sleep 1
            Start-Process "http://localhost:3000"
            return
        }
        Write-Host "    Still starting... ($i/40)" -ForegroundColor Gray
    }
    Write-Host "[WARN] Timeout - opening browser anyway" -ForegroundColor Yellow
    Start-Process "http://localhost:3000"
}

Write-Host ""
Write-Host "================================================" -ForegroundColor Blue
Write-Host "  DMS - Production Mode" -ForegroundColor Blue
Write-Host "================================================" -ForegroundColor Blue
Write-Host ""

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "[ERROR] Run as Administrator" -ForegroundColor Red
    Read-Host
    exit 1
}
Write-Host "[OK] Administrator" -ForegroundColor Green

try { node --version | Out-Null }
catch {
    Write-Host "[ERROR] Node.js not found. Run START.bat first." -ForegroundColor Red
    Read-Host
    exit 1
}
Write-Host "[OK] Node.js found" -ForegroundColor Green

Write-Host ""
Write-Host "Starting MySQL..." -ForegroundColor Cyan

Get-Process -Name mysqld -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep 1
Remove-Item "C:\xampp\mysql\data\multi-master.info" -Force -ErrorAction SilentlyContinue
Get-ChildItem "C:\xampp\mysql\data\" -File |
    Where-Object { $_.Name -match "^(master-|relay-log-|mysql-relay-bin-)" } |
    Remove-Item -Force -ErrorAction SilentlyContinue

$startedViaSvc = $false
foreach ($svc in @("MYSQL80","mysql80","MySQL","mysql")) {
    $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
    if ($s) {
        if ($s.Status -ne "Running") {
            Start-Service $svc -ErrorAction SilentlyContinue | Out-Null
            Start-Sleep 3
        }
        $s2 = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s2.Status -eq "Running") { $startedViaSvc = $true }
        break
    }
}

if (-not $startedViaSvc -and -not (Get-Process -Name mysqld -ErrorAction SilentlyContinue)) {
    if (Test-Path "C:\xampp\mysql\bin\mysqld.exe") {
        Set-Location "C:\xampp\mysql\bin"
        Start-Process "C:\xampp\mysql\bin\mysqld.exe" -ArgumentList "--defaults-file=C:\xampp\mysql\bin\my.ini" -WindowStyle Hidden
    }
}

$mysqlReady = $false
for ($i = 1; $i -le 10; $i++) {
    Start-Sleep 3
    $ping2 = & "C:\xampp\mysql\bin\mysqladmin.exe" -u root ping 2>$null
    if ($ping2 -match "alive") {
        $mysqlReady = $true
        break
    }
    Write-Host "    Waiting for MySQL... ($i/10)" -ForegroundColor Yellow
}

if (-not $mysqlReady) {
    $host.UI.RawUI.WindowTitle = "DMS ERROR"
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Red
    Write-Host "  DMS ERROR - MySQL did not start" -ForegroundColor Red
    Write-Host "================================================" -ForegroundColor Red
    Write-Host "  Open C:\xampp\xampp-control.exe" -ForegroundColor Yellow
    Write-Host "  Start MySQL manually, then retry." -ForegroundColor Yellow
    Write-Host "================================================" -ForegroundColor Red
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host "[OK] MySQL is ready" -ForegroundColor Green

Write-Host ""
Write-Host "Starting Apache..." -ForegroundColor Cyan
$apacheStarted = $false
foreach ($svc in @("Apache2.4","apache2.4","Apache","apache")) {
    $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
    if ($s) {
        if ($s.Status -ne "Running") {
            Start-Service $svc -ErrorAction SilentlyContinue | Out-Null
            Start-Sleep 2
        }
        $s2 = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s2.Status -eq "Running") { $apacheStarted = $true }
        break
    }
}
if (-not $apacheStarted -and -not (Get-Process -Name httpd -ErrorAction SilentlyContinue)) {
    if (Test-Path "C:\xampp\apache\bin\httpd.exe") {
        Start-Process "C:\xampp\apache\bin\httpd.exe" -WindowStyle Hidden
        Start-Sleep 2
    }
}
if (Get-Process -Name httpd -ErrorAction SilentlyContinue) {
    Write-Host "[OK] Apache running" -ForegroundColor Green
} else {
    Write-Host "[WARN] Apache did not start - phpMyAdmin unavailable" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Starting Mosquitto..." -ForegroundColor Cyan
$env:Path += ";C:\Program Files\Mosquitto"
$mqttConf = "C:\Program Files\Mosquitto\mosquitto-dms.conf"
if (-not (Test-Path $mqttConf)) {
    $t = "listener 1883 0.0.0.0`r`nprotocol mqtt`r`nallow_anonymous true`r`n`r`nlistener 9001 0.0.0.0`r`nprotocol websockets`r`nallow_anonymous true`r`n"
    [System.IO.File]::WriteAllText($mqttConf, $t, [System.Text.Encoding]::ASCII)
}
Stop-Process -Name mosquitto -Force -ErrorAction SilentlyContinue
Start-Sleep 1
$mqSvc = Get-Service -Name mosquitto -ErrorAction SilentlyContinue
if ($mqSvc) {
    Stop-Service mosquitto -Force -ErrorAction SilentlyContinue
    Set-Service mosquitto -StartupType Manual -ErrorAction SilentlyContinue
    Start-Sleep 1
    Stop-Process -Name mosquitto -Force -ErrorAction SilentlyContinue
}
Start-Process "C:\Program Files\Mosquitto\mosquitto.exe" -ArgumentList "-c `"$mqttConf`"" -WindowStyle Hidden
Start-Sleep 2
if (Get-Process -Name mosquitto -ErrorAction SilentlyContinue) {
    Write-Host "[OK] Mosquitto running (TCP:1883, WS:9001)" -ForegroundColor Green
} else {
    Write-Host "[WARN] Mosquitto may not be running" -ForegroundColor Yellow
}

$localIP = "localhost"
try {
    $ip = (Get-NetIPAddress -AddressFamily IPv4 |
        Where-Object { $_.IPAddress -notmatch "^127\." -and $_.IPAddress -notmatch "^169\.254\." -and $_.IPAddress -notmatch "^172\." } |
        Select-Object -First 1).IPAddress
    if ($ip) { $localIP = $ip }
} catch { }

Write-Host ""
Write-Host "Clearing ports 3000 and 5004..." -ForegroundColor Cyan
Kill-Port 3000
Kill-Port 5004
Start-Sleep 1

$needsBuild = -not (Test-Path "$FRONTEND\.next\BUILD_ID")
if ($needsBuild) {
    Write-Host ""
    Write-Host "Building frontend for production (~3 min)..." -ForegroundColor Yellow
    Set-Location $FRONTEND
    npm run build
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[WARN] Build failed, falling back to dev mode" -ForegroundColor Yellow
        $useDev = $true
    } else {
        Write-Host "[OK] Frontend built" -ForegroundColor Green
        $useDev = $false
    }
} else {
    Write-Host "[OK] Frontend already built" -ForegroundColor Green
    $useDev = $false
}

Write-Host ""
Write-Host "Setting up Desktop shortcuts..." -ForegroundColor Cyan
Create-Shortcuts
Write-Host "[OK] Desktop shortcuts ready - DMS Start + DMS Stop" -ForegroundColor Green

Write-Host ""
Write-Host "Launching DMS servers..." -ForegroundColor Cyan
$backendCmd = "/k title DMS Backend :5004 && color 0B && cd /d `"$BACKEND`" && node server.js"
Start-Process "cmd.exe" -ArgumentList $backendCmd -WindowStyle Hidden
Start-Sleep 2

if ($useDev) {
    $frontendCmd = "/k title DMS Frontend DEV :3000 && color 0E && cd /d `"$FRONTEND`" && npm run dev"
} else {
    $frontendCmd = "/k title DMS Frontend PROD :3000 && color 0E && cd /d `"$FRONTEND`" && npm start"
}
Start-Process "cmd.exe" -ArgumentList $frontendCmd -WindowStyle Hidden

Write-Host "[OK] Servers launched in background" -ForegroundColor Green
Write-Host ""
Write-Host "================================================" -ForegroundColor Green
Write-Host "  DMS IS STARTING..." -ForegroundColor Green
Write-Host "  Browser opens automatically when ready." -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Green
Write-Host ""

Wait-ForApp

Write-Host ""
Write-Host "  This window closes in 5 seconds." -ForegroundColor Gray
Start-Sleep 5
exit 0
