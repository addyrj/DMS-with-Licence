'use client';
// src/app/(employee)/employee/dashboard/page.js
// UPDATED:
// - Display card now has "View Details" link → /employee/displays/[id]
// - Removed "Upload Content" button (merged into Publish Content page)
// - "Publish Content" button navigates to /employee/publish
import { useAuth } from '../../../../lib/auth';
import { useQuery } from '@tanstack/react-query';
import { getUsers, getDisplay, getLines, getDisplays } from '../../../../lib/api';
import { fmt } from '../../../../lib/utils';
import Card from '../../../../components/ui/Card';
import Badge from '../../../../components/ui/Badge';
import Button from '../../../../components/ui/Button';
import StatCard from '../../../../components/ui/StatCard';
import Link from 'next/link';
import { Monitor, Send, GitBranch, Clock, ExternalLink } from 'lucide-react';

export default function EmployeeDashboard() {
  const { user } = useAuth();

  const { data: usersData } = useQuery({ queryKey:['users'], queryFn: getUsers });
  const me = usersData?.users?.find(u => u.username === user?.username);

  const { data: displayData } = useQuery({
    queryKey: ['display', me?.assigned_display_id],
    queryFn:  () => getDisplay(me.assigned_display_id),
    enabled:  !!me?.assigned_display_id,
    refetchInterval: 15_000,
  });
  const display = displayData?.display;

  // All displays in their production line (for the displays grid)
  const { data: displaysData } = useQuery({ queryKey:['displays'], queryFn: getDisplays });
  const lineDisplays = displaysData?.displays || [];

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>My Dashboard</h2>
          <p>Welcome back, {user?.username}</p>
        </div>
        <Link href="/employee/publish">
          <Button variant="primary"><Send size={16}/> Publish Content</Button>
        </Link>
      </div>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))', gap:16, marginBottom:24 }}>
        <StatCard icon={GitBranch} label="My Production Line" value={me?.production_line_name || '—'}       color="primary"/>
        <StatCard icon={Monitor}   label="My Display"          value={me?.display_number || '—'}             color="secondary"/>
        <StatCard icon={Monitor}   label="Display Status"      value={display ? display.status : '—'}
          color={display?.status==='ONLINE'?'success':'danger'}/>
        <StatCard icon={Clock}     label="Uptime Today"
          value={display?.uptime_today_minutes
            ? `${Math.floor(display.uptime_today_minutes/60)}h ${display.uptime_today_minutes%60}m`
            : '—'}
          color="warning"/>
      </div>

      <div className="two-col">
        {/* My Display card — with link to detail */}
        <Card title="My Display" subtitle={me?.display_number || 'No display assigned'}>
          {!me?.assigned_display_id ? (
            <div className="empty">
              <div className="empty__icon">📺</div>
              <div className="empty__title">No display assigned</div>
              <p>Contact your admin to get a display assignment</p>
            </div>
          ) : !display ? (
            <div className="empty"><div className="spinner" style={{ margin:'0 auto' }}/></div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {[
                { label:'Status',       value: <Badge variant={display.status==='ONLINE'?'success':'danger'} dot>{display.status}</Badge> },
                { label:'Volume',       value: `${display.volume_level}%` },
                { label:'Last Seen',    value: fmt.ago(display.last_heartbeat) },
                { label:'Loops Today',  value: display.content_loops_today || 0 },
                { label:'Content Size', value: fmt.bytes(display.media_storage_mb || 0) },
              ].map(row => (
                <div key={row.label} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 12px', background:'var(--bg-main)', borderRadius:'var(--radius-sm)' }}>
                  <span style={{ fontSize:13, color:'var(--text-muted)', fontWeight:600 }}>{row.label}</span>
                  <span style={{ fontSize:14, fontWeight:700 }}>{row.value}</span>
                </div>
              ))}
              {/* Link to detail page */}
              <Link href={`/employee/displays/${display.id}`} style={{ marginTop:8 }}>
                <Button variant="secondary" style={{ width:'100%' }}>
                  <ExternalLink size={14}/> View Display Details
                </Button>
              </Link>
            </div>
          )}
        </Card>

        {/* All displays in my line */}
        <Card title="Displays in My Line" subtitle="All TVs you're responsible for">
          {lineDisplays.length === 0 ? (
            <div className="empty">
              <div className="empty__icon">📺</div>
              <div className="empty__title">No displays found</div>
              <p>You may not have a production line assigned yet</p>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {lineDisplays.map(d => (
                <div key={d.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 12px', background:'var(--bg-main)', borderRadius:'var(--radius-sm)', border:'1px solid var(--border)' }}>
                  <div style={{ width:8, height:8, borderRadius:'50%', background: d.status==='ONLINE'?'var(--success)':'var(--danger)', flexShrink:0 }}/>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontWeight:700, fontSize:13, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{d.display_name}</div>
                    <code style={{ fontSize:11, color:'var(--text-muted)' }}>{d.display_number}</code>
                  </div>
                  <Badge variant={d.status==='ONLINE'?'success':'danger'}>{d.status}</Badge>
                  <Link href={`/employee/displays/${d.id}`}>
                    <Button variant="ghost" size="sm" title="View details">
                      <ExternalLink size={13} color="var(--primary)"/>
                    </Button>
                  </Link>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Quick actions */}
      <Card title="Quick Actions" style={{ marginTop:20 }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:12 }}>
          {[
            { label:'Publish Content',   href:'/employee/publish',      icon:'📺', desc:'Push files to TVs' },
            { label:'Upload to Library', href:'/employee/media-bucket', icon:'📁', desc:'Add files to your bucket' },
            { label:'My Displays',       href:'/employee/displays',     icon:'🖥️', desc:'View & manage TVs' },
          ].map(a => (
            <Link key={a.href} href={a.href}>
              <div style={{ padding:'16px', background:'var(--bg-main)', borderRadius:'var(--radius-md)', border:'1px solid var(--border)', cursor:'pointer', transition:'all .15s' }}
                onMouseEnter={e => e.currentTarget.style.borderColor='var(--primary)'}
                onMouseLeave={e => e.currentTarget.style.borderColor='var(--border)'}>
                <div style={{ fontSize:28, marginBottom:8 }}>{a.icon}</div>
                <div style={{ fontWeight:700, fontSize:14, marginBottom:4 }}>{a.label}</div>
                <div style={{ fontSize:12, color:'var(--text-muted)' }}>{a.desc}</div>
              </div>
            </Link>
          ))}
        </div>
      </Card>
    </div>
  );
}
