'use client';
// src/app/(employee)/employee/publish/page.js
// FIX: Direct TV Upload tab now has doc_duration field
import React, { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getContent, getContentFiles, setDuration, deleteContentFile,
  getLines, getDisplays, getFolders, getFolderFiles,
  publishContent, unpublishContent, getPublishStatus, republishContent, deletePublishedContent, deletePublishHistory,
  uploadFiles as uploadFilesApi, getContentByLine, directUpload,
  getAssignments, toggleAssignment, deleteAssignment, createAssignment,
  getPublishHistory,
} from '../../../../lib/api';
import { fmt, thumbUrl, isDocType } from '../../../../lib/utils';
import Card from '../../../../components/ui/Card';
import Badge from '../../../../components/ui/Badge';
import Button from '../../../../components/ui/Button';
import Modal from '../../../../components/ui/Modal';
import ConfirmModal from '../../../../components/ui/ConfirmModal';
import ProgressBar from '../../../../components/ui/ProgressBar';
import { Field, Input, Select } from '../../../../components/ui/Input';
import { useToast } from '../../../../components/ui/Toast';
import { Send, StopCircle, ChevronDown, ChevronUp, Trash2, Clock, Monitor, LayoutGrid, List, AlertTriangle, Tv } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import FilePreview from '../../../../components/ui/FilePreview';

const PUB_TABS  = ['From Library', 'Upload New', 'Direct TV Upload'];
const FILE_ICON = { video:'🎬', image:'🖼️', pdf:'📄', presentation:'📊' };

function TvCard({ tv }) {
  const [imgErr, setImgErr] = useState({});
  return (
    <div style={{ background:'white', borderRadius:'var(--radius-lg)', overflow:'hidden', boxShadow:'var(--shadow-sm)', border:'1px solid var(--border)', display:'flex', flexDirection:'column' }}>
      <div style={{ padding:'12px 14px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:10 }}>
        <div style={{ width:8, height:8, borderRadius:'50%', background: tv.status==='ONLINE'?'var(--success)':'var(--danger)', flexShrink:0 }}/>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontWeight:700, fontSize:13, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{tv.display_name}</div>
          <code style={{ fontSize:11, color:'var(--text-muted)' }}>{tv.display_number}</code>
        </div>
        <Badge variant={tv.status==='ONLINE'?'success':'danger'}>{tv.status}</Badge>
      </div>
      <div style={{ flex:1, padding:'10px 12px', display:'flex', flexDirection:'column', gap:6 }}>
        {tv.files.length === 0
          ? <div style={{ textAlign:'center', padding:'16px 0', color:'var(--text-muted)', fontSize:12 }}>No content published</div>
          : tv.files.map((f, idx) => (
            <div key={f.id} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 8px', background:'var(--bg-main)', borderRadius:'var(--radius-sm)', border:'1px solid var(--border)' }}>
              <div style={{ width:20, height:20, borderRadius:'50%', background:'var(--primary)', color:'white', display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:700, flexShrink:0 }}>{idx+1}</div>
              {f.file_type==='image' && thumbUrl(f.file_path) && !imgErr[f.id]
                ? <div style={{ width:34, height:34, borderRadius:4, overflow:'hidden', flexShrink:0 }}><img src={thumbUrl(f.file_path)} alt="" style={{ width:'100%', height:'100%', objectFit:'cover' }} onError={()=>setImgErr(p=>({...p,[f.id]:true}))}/></div>
                : <span style={{ fontSize:16, flexShrink:0 }}>{FILE_ICON[f.file_type]||'📄'}</span>}
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:11, fontWeight:600, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{f.file_name}</div>
                <div style={{ fontSize:10, color:'var(--text-muted)' }}>{isDocType(f.file_name)?`${f.duration||50}s/pg`:`${f.duration||10}s`}</div>
              </div>
            </div>
          ))}
      </div>
      <div style={{ padding:'8px 12px', borderTop:'1px solid var(--border)', fontSize:11, color:'var(--text-muted)', display:'flex', justifyContent:'space-between' }}>
        <span>{tv.files.length} file{tv.files.length!==1?'s':''}</span>
        {tv.last_heartbeat && <span>{fmt.ago(tv.last_heartbeat)}</span>}
      </div>
    </div>
  );
}

export default function ContentPage() {
  const toast = useToast();
  const qc    = useQueryClient();

  const { data: contentData } = useQuery({ queryKey:['content'],     queryFn: getContent });
  const { data: linesData   } = useQuery({ queryKey:['lines'],       queryFn: getLines });
  const { data: foldersData } = useQuery({ queryKey:['folders'],     queryFn: getFolders });
  const { data: displaysData} = useQuery({ queryKey:['displays'],    queryFn: getDisplays });
  const { data: asgData, refetch: refetchAsg } = useQuery({ queryKey:['assignments'], queryFn: getAssignments });
  const { data: histData } = useQuery({ queryKey:['publish-history'], queryFn: getPublishHistory });
  const publishHistory = histData?.history || [];

  const content     = contentData?.content    || [];
  const lines       = linesData?.lines        || [];
  const folders     = foldersData?.folders    || [];
  const allDisplays = displaysData?.displays  || [];
  const assignments = asgData?.assignments    || [];

  const [viewMode, setViewMode]   = useState('cards');
  const [selLine,  setSelLine]    = useState('');
  const [expId,    setExpId]      = useState(null);
  const [editDurId,setEditDurId]  = useState(null);
  const [newDur,   setNewDur]     = useState('');
  const [delFileM, setDelFileM]   = useState(null);
  const [delAsgM,  setDelAsgM]    = useState(null);
  const [statLine, setStatLine]   = useState(null);

  // Modal
  const [pubModal, setPubModal]   = useState(false);
  const [pubTab,   setPubTab]     = useState('From Library');
  const [pubLineMode, setPubLineMode] = useState('one');
  const [pubLineId,   setPubLineId]   = useState('');
  const [pubDispMode, setPubDispMode] = useState('all');
  const [pubSelDisps, setPubSelDisps] = useState([]);
  const [pubFolder,   setPubFolder]   = useState('');
  const [selFiles,    setSelFiles]    = useState([]);
  const [upFiles,     setUpFiles]     = useState([]);
  const [upFolder,    setUpFolder]    = useState('');
  const [dtLineId,    setDtLineId]    = useState('');
  const [dtDispNum,   setDtDispNum]   = useState('');
  const [dtFiles,     setDtFiles]     = useState([]);
  const [pubDur,      setPubDur]      = useState('10');
  const [pubDocDur,   setPubDocDur]   = useState('50');
  const [uploading,   setUploading]   = useState(false);
  const [appendMode,  setAppendMode]  = useState(false);
  const [previewFile, setPreviewFile] = useState(null);
  const [newAsgModal, setNewAsgModal] = useState(false);
  const [asgFolder,   setAsgFolder]   = useState('');
  const [asgFileId,   setAsgFileId]   = useState('');
  const [asgDispId,   setAsgDispId]   = useState('');
  const [asgDur,      setAsgDur]      = useState('10');
  const [asgDocDur,   setAsgDocDur]   = useState('50');
  const [creatingAsg, setCreatingAsg] = useState(false);

  const displaysInLine = (() => {
    if (pubLineMode==='all') return allDisplays;
    if (!pubLineId) return [];
    const line = lines.find(l=>String(l.id)===String(pubLineId));
    if (!line) return [];
    const nums = (line.display_numbers||'').split(',').map(s=>s.trim()).filter(Boolean);
    return nums.length ? allDisplays.filter(d=>nums.includes(d.display_number)) : allDisplays;
  })();

  const dtDisplays = (() => {
    if (!dtLineId) return allDisplays;
    const line = lines.find(l=>String(l.id)===String(dtLineId));
    if (!line) return allDisplays;
    const nums = (line.display_numbers||'').split(',').map(s=>s.trim()).filter(Boolean);
    return nums.length ? allDisplays.filter(d=>nums.includes(d.display_number)) : allDisplays;
  })();

  const onDrop   = useCallback(a=>setUpFiles(p=>[...p,...a]),[]);
  const onDropDt = useCallback(a=>setDtFiles(p=>[...p,...a]),[]);
  const { getRootProps:getUpRootProps, getInputProps:getUpInputProps, isDragActive:isUpDrag } = useDropzone({ onDrop });
  const { getRootProps:getDtRootProps, getInputProps:getDtInputProps, isDragActive:isDtDrag } = useDropzone({ onDrop: onDropDt });

  const { data: cardData, isLoading: cardLoading } = useQuery({
    queryKey:['content-by-line', selLine], queryFn:()=>getContentByLine(selLine), enabled:!!selLine&&viewMode==='cards',
  });
  const tvCards = cardData?.tvs || [];

  const { data: folderFilesData } = useQuery({
    queryKey:['pub-folder', pubFolder], queryFn:()=>getFolderFiles(pubFolder), enabled:!!pubFolder&&pubTab==='From Library',
  });
  const folderFiles = folderFilesData?.files || [];

  const { data: asgFolderData } = useQuery({
    queryKey:['asg-folder', asgFolder], queryFn:()=>getFolderFiles(asgFolder), enabled:!!asgFolder&&newAsgModal,
  });
  const asgFolderFiles = asgFolderData?.files || [];
  const hasDocFiles = folderFiles.some(f=>isDocType(f.file_name));

  const { data: filesData } = useQuery({
    queryKey:['content-files', expId], queryFn:()=>getContentFiles(expId), enabled:!!expId,
  });
  const expFiles = filesData?.files || [];

  const { data: statusData } = useQuery({
    queryKey:['pub-status', statLine], queryFn:()=>getPublishStatus(statLine), enabled:!!statLine, refetchInterval:3000,
  });

  const publishMut = useMutation({
    mutationFn: publishContent,
    onSuccess: (d) => {
      qc.invalidateQueries({ queryKey:['content'] }); qc.invalidateQueries({ queryKey:['content-by-line'] });
      setPubModal(false); if(pubLineId) setStatLine(Number(pubLineId));
      toast(`✅ Published to ${d.tv_count} TV(s)!`);
    },
    onError: (e) => toast(e.message,'danger'),
  });
  const deleteContentMut = useMutation({
    mutationFn: deletePublishedContent,
    onSuccess: ()=>{ qc.invalidateQueries({queryKey:['content']}); qc.invalidateQueries({queryKey:['content-by-line']}); toast('Content deleted'); },
    onError: (e)=>toast(e.message,'danger'),
  });
  const deleteHistMut = useMutation({
    mutationFn: (id)=>deletePublishHistory(id),
    onSuccess: ()=>{ qc.invalidateQueries({queryKey:['publish-history']}); toast('History removed'); },
    onError: (e)=>toast(e.message,'danger'),
  });
  const republishMut = useMutation({
    mutationFn: republishContent,
    onSuccess: ()=>{ qc.invalidateQueries({queryKey:['content']}); qc.invalidateQueries({queryKey:['content-by-line']}); toast('✅ Content resumed!'); },
    onError: (e)=>toast(e.message,'danger'),
  });

  const unpublishMut = useMutation({
    mutationFn: unpublishContent,
    onSuccess: ()=>{ qc.invalidateQueries({queryKey:['content']}); qc.invalidateQueries({queryKey:['content-by-line']}); toast('Unpublished'); },
    onError: (e)=>toast(e.message,'danger'),
  });
  const durMut = useMutation({
    mutationFn: ({id,dur})=>setDuration(id,{duration:dur}),
    onSuccess: ()=>{ qc.invalidateQueries({queryKey:['content']}); setEditDurId(null); toast('Duration updated'); },
    onError: (e)=>toast(e.message,'danger'),
  });
  const delFileMut = useMutation({
    mutationFn: (fid)=>deleteContentFile(fid),
    onSuccess: ()=>{ qc.invalidateQueries({queryKey:['content']}); qc.invalidateQueries({queryKey:['content-files',expId]}); setDelFileM(null); toast('File removed'); },
    onError: (e)=>toast(e.message,'danger'),
  });
  const toggleAsgMut = useMutation({ mutationFn:(id)=>toggleAssignment(id), onSuccess:()=>refetchAsg(), onError:(e)=>toast(e.message,'danger') });
  const delAsgMut = useMutation({
    mutationFn:(id)=>deleteAssignment(id),
    onSuccess:()=>{ refetchAsg(); setDelAsgM(null); toast('Assignment removed'); },
    onError:(e)=>toast(e.message,'danger'),
  });

  const openModal = () => {
    setPubTab('From Library'); setPubLineMode('one'); setPubLineId(''); setPubDispMode('all'); setPubSelDisps([]);
    setPubFolder(''); setSelFiles([]); setUpFiles([]); setUpFolder(''); setDtLineId(''); setDtDispNum(''); setDtFiles([]);
    setPubDur('10'); setPubDocDur('50'); setPubModal(true);
  };

  const handlePublish = async () => {
    if (pubTab === 'Direct TV Upload') {
      if (!dtDispNum) return toast('Select a target display','warning');
      if (!dtFiles.length) return toast('Add files to upload','warning');
      setUploading(true);
      try {
        const fd = new FormData();
        fd.append('production_line_id', dtLineId || lines[0]?.id || '1');
        fd.append('display_number', dtDispNum);
        fd.append('duration', pubDur);
        fd.append('doc_duration', pubDocDur); // FIX: now sends doc_duration
        dtFiles.forEach(f=>fd.append('images',f));
        await directUpload(fd);
        qc.invalidateQueries({queryKey:['content']}); qc.invalidateQueries({queryKey:['content-by-line']});
        setPubModal(false); toast(`✅ Uploaded to ${dtDispNum}!`);
      } catch(e) { toast(e.message,'danger'); }
      finally { setUploading(false); }
      return;
    }
    if (pubLineMode==='one' && !pubLineId) return toast('Select a production line','warning');
    const payload = {
      folder_name:  pubFolder||upFolder.trim(),
      duration:     Number(pubDur),
      doc_duration: Number(pubDocDur),
      file_ids:     selFiles.length>0?selFiles:undefined,
      display_ids:  (pubDispMode==='specific'&&pubSelDisps.length>0)?pubSelDisps:undefined,
    };
    if (appendMode) payload.append_mode = true;
    if (pubLineMode==='all') payload.all_lines = true;
    else payload.production_line_id = Number(pubLineId);

    if (pubTab==='From Library') {
      if (!pubFolder) return toast('Select a folder','warning');
      publishMut.mutate(payload);
    } else {
      if (!upFolder.trim()) return toast('Enter folder name','warning');
      if (!upFiles.length)  return toast('Select files','warning');
      setUploading(true);
      try {
        await uploadFilesApi(upFolder.trim(), upFiles);
        qc.invalidateQueries({queryKey:['folders']});
        publishMut.mutate(payload);
      } catch(e) { toast(e.message,'danger'); }
      finally { setUploading(false); }
    }
  };

  const toggleFile = (id)=>setSelFiles(p=>p.includes(id)?p.filter(x=>x!==id):[...p,id]);
  const toggleDisp = (id)=>setPubSelDisps(p=>p.includes(id)?p.filter(x=>x!==id):[...p,id]);

  const durationRow = (
    <div style={{ background:'var(--bg-main)', borderRadius:'var(--radius-md)', padding:14 }}>
      <div style={{ fontWeight:700, fontSize:13, marginBottom:10 }}>Duration Settings</div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
        <Field label="Image / Video (sec)"><Input type="number" min={1} value={pubDur} onChange={e=>setPubDur(e.target.value)}/></Field>
        <Field label="Doc per-page (sec)"><Input type="number" min={5} value={pubDocDur} onChange={e=>setPubDocDur(e.target.value)}/></Field>
      </div>
      {hasDocFiles && pubTab!=='Direct TV Upload' && (
        <div style={{ marginTop:8, background:'#FFF7ED', border:'1px solid var(--warning)', borderRadius:'var(--radius-sm)', padding:'8px 12px', fontSize:12, color:'var(--warning)', display:'flex', gap:6 }}>
          <AlertTriangle size={12} style={{ flexShrink:0, marginTop:1 }}/><span>Folder has PDF/PPT — doc duration ({pubDocDur}s/pg) applies</span>
        </div>
      )}
    </div>
  );

  return (
    <div>
      <div className="page-header">
        <div><h2>Publish Content</h2><p>Push your media to your assigned TVs</p></div>
        <Button variant="primary" onClick={openModal}><Send size={16}/> Publish Content</Button>
      </div>

      {statusData && (
        <Card style={{ marginBottom:20, border:'2px solid var(--primary)' }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
            <div style={{ fontWeight:700 }}>📡 Download Progress</div>
            <Button variant="ghost" size="sm" onClick={()=>setStatLine(null)}>✕</Button>
          </div>
          <div style={{ marginBottom:10 }}>
            <div style={{ display:'flex', justifyContent:'space-between', fontSize:13, marginBottom:4 }}>
              <span>{statusData.completed}/{statusData.total} TVs done</span>
              <span style={{ fontWeight:700, color:'var(--primary)' }}>{Math.round((statusData.completed/Math.max(statusData.total,1))*100)}%</span>
            </div>
            <ProgressBar value={statusData.completed} max={statusData.total||1} size="md"/>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(160px,1fr))', gap:8 }}>
            {(statusData.tvs||[]).map(tv=>(
              <div key={tv.display_id} style={{ padding:'6px 10px', background:'var(--bg-main)', borderRadius:'var(--radius-sm)', fontSize:12, display:'flex', justifyContent:'space-between' }}>
                <span style={{ fontWeight:600 }}>{tv.display_number}</span>
                <span>{{completed:'✅',downloading:'⬇️',pending:'⏳'}[tv.status]} {tv.status}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:20, flexWrap:'wrap' }}>
        <div style={{ display:'flex', borderRadius:'var(--radius-sm)', overflow:'hidden', border:'1px solid var(--border)' }}>
          {[{v:'cards',l:'TV Cards'},{v:'table',l:'Table'}].map(m=>(
            <button key={m.v} onClick={()=>setViewMode(m.v)} style={{ padding:'8px 14px', cursor:'pointer', border:'none', fontSize:13, fontWeight:600,
              background:viewMode===m.v?'var(--primary)':'white', color:viewMode===m.v?'white':'var(--text-body)' }}>
              {m.l}
            </button>
          ))}
        </div>
        {viewMode==='cards' && (
          <Select value={selLine} onChange={e=>setSelLine(e.target.value)} style={{ width:260 }}>
            <option value="">Select production line...</option>
            {lines.map(l=><option key={l.id} value={l.id}>{l.production_line_name}</option>)}
          </Select>
        )}
      </div>

      {viewMode==='cards' && (
        !selLine ? (
          <Card><div className="empty"><div style={{ fontSize:48,marginBottom:12 }}>📺</div><div className="empty__title">Select a line above</div></div></Card>
        ) : cardLoading ? (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))', gap:16 }}>
            {[...Array(4)].map((_,i)=><div key={i} className="skeleton" style={{ height:240,borderRadius:'var(--radius-lg)' }}/>)}
          </div>
        ) : tvCards.length===0 ? (
          <Card><div className="empty"><div className="empty__icon">📺</div><div className="empty__title">No displays in this line</div></div></Card>
        ) : (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))', gap:16 }}>
            {tvCards.map(tv=><TvCard key={tv.id} tv={tv}/>)}
          </div>
        )
      )}

      {viewMode==='table' && (
        <Card title="Published Content" style={{ marginBottom:20 }}>
          <div className="table-wrap">
            <table className="table">
              <thead><tr><th>Display</th><th>Line</th><th>Files</th><th>Duration</th><th>Status</th><th>Updated</th><th>Actions</th></tr></thead>
              <tbody>
                {content.map(c=>(
                  <React.Fragment key={c.id}>
                    <tr>
                      <td><div className="table__name">{c.display_name||c.display_number}</div><code style={{fontSize:11,color:'var(--text-muted)'}}>{c.display_number}</code></td>
                      <td style={{fontSize:13}}>{c.production_line_name}</td>
                      <td><Badge variant="primary">{c.file_count} files</Badge></td>
                      <td>
                        {editDurId===c.id ? (
                          <div style={{display:'flex',gap:6,alignItems:'center'}}>
                            <Input type="number" value={newDur} onChange={e=>setNewDur(e.target.value)} style={{width:70,height:30,fontSize:13}}/>
                            <Button variant="primary" size="sm" loading={durMut.isPending} onClick={()=>durMut.mutate({id:c.id,dur:Number(newDur)})}>✓</Button>
                            <Button variant="ghost" size="sm" onClick={()=>setEditDurId(null)}>✕</Button>
                          </div>
                        ) : (
                          <div style={{display:'flex',alignItems:'center',gap:8}}>
                            <span style={{fontSize:13}}>{c.duration}s</span>
                            <button onClick={()=>{setEditDurId(c.id);setNewDur(c.duration);}} style={{padding:'2px 5px',border:'1px solid var(--border)',borderRadius:5,cursor:'pointer',background:'white',fontSize:10}}><Clock size={10}/></button>
                          </div>
                        )}
                      </td>
                      <td><Badge variant={c.is_published?'success':'warning'}>{c.is_published?'Published':'⏸ Paused'}</Badge></td>
                      <td style={{fontSize:12,color:'var(--text-muted)'}}>{fmt.ago(c.updated_at)}</td>
                      <td>
                        <div style={{display:'flex',gap:6}}>
                          {c.is_published ? (
                            <Button variant="warning" size="sm" title="Pause" loading={unpublishMut.isPending} onClick={()=>unpublishMut.mutate({production_line_id:Number(c.production_line_id)})}>⏸</Button>
                          ) : (
                            <Button variant="success" size="sm" title="Resume" loading={republishMut.isPending} onClick={()=>republishMut.mutate({production_line_id:Number(c.production_line_id)})}>▶</Button>
                          )}
                          <Button variant="danger" size="sm" title="Delete permanently" loading={deleteContentMut.isPending}
                            onClick={()=>{if(confirm('Permanently delete ALL content?')) deleteContentMut.mutate({production_line_id:Number(c.production_line_id)});}}>🗑</Button>
                          <Button variant="ghost" size="sm" onClick={()=>setExpId(expId===c.id?null:c.id)}>{expId===c.id?<ChevronUp size={14}/>:<ChevronDown size={14}/>}</Button>
                        </div>
                      </td>
                    </tr>
                    {expId===c.id && (
                      <tr key={`exp-${c.id}`}><td colSpan={7} style={{padding:'0 16px 12px',background:'var(--bg-main)'}}>
                        <table className="table" style={{margin:0,border:'1px solid var(--border)',borderRadius:'var(--radius-sm)',overflow:'hidden'}}>
                          <thead><tr><th>#</th><th>Preview</th><th>File</th><th>Type</th><th>Duration</th><th></th></tr></thead>
                          <tbody>
                            {expFiles.map((f,i)=>(
                              <tr key={f.id}>
                                <td style={{fontSize:12,color:'var(--text-muted)'}}>{f.sequence_order||i+1}</td>
                                <td><div onClick={()=>setPreviewFile(f)} style={{cursor:'pointer'}}>{f.file_type==='image'&&thumbUrl(f.file_path)?<div style={{width:32,height:32,borderRadius:4,overflow:'hidden',border:'1px solid var(--border)'}}><img src={thumbUrl(f.file_path)} alt="" style={{width:'100%',height:'100%',objectFit:'cover'}} onError={e=>{e.target.style.display='none'}}/></div>:<span style={{fontSize:16}}>{FILE_ICON[f.file_type]||'📄'}</span>}</div></td>
                                <td><div className="table__name" style={{fontSize:12}}>{f.file_name}</div></td>
                                <td><Badge variant="primary">{f.file_type}</Badge></td>
                                <td style={{fontSize:12,color:'var(--text-muted)'}}>{isDocType(f.file_name)?<span>{f.doc_duration_seconds||f.duration||50}s/pg</span>:<span>{f.duration||10}s</span>}</td>
                                <td><Button variant="ghost" size="sm" onClick={()=>setDelFileM(f)}><Trash2 size={12} color="var(--danger)"/></Button></td>
                              </tr>
                            ))}
                            {!expFiles.length && <tr key="ef-none"><td colSpan={6}><div className="empty" style={{padding:10}}><div className="empty__title">No files</div></div></td></tr>}
                          </tbody>
                        </table>
                      </td></tr>
                    )}
                  </React.Fragment>
                ))}
                {!content.length && <tr key="ct-none"><td colSpan={7}><div className="empty"><div className="empty__icon">📺</div><div className="empty__title">No published content</div></div></td></tr>}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* DIRECT ASSIGNMENTS UI — temporarily hidden
      <Card title="Direct Assignments" subtitle="Files assigned directly to individual displays"
        action={<Button variant="secondary" size="sm" onClick={()=>setNewAsgModal(true)}>+ New Assignment</Button>}>
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>File</th><th>Type</th><th>Display</th><th>Duration</th><th>Active</th><th>Assigned</th><th></th></tr></thead>
            <tbody>
              {assignments.map(a=>(
                <tr key={a.id}>
                  <td><div style={{display:'flex',alignItems:'center',gap:8}}><span style={{fontSize:16}}>{FILE_ICON[a.file_type]||'📄'}</span><div className="table__name">{a.file_name}</div></div></td>
                  <td><Badge variant="primary">{a.file_type}</Badge></td>
                  <td><code style={{fontSize:12}}>{a.display_number}</code></td>
                  <td style={{fontSize:13}}>{a.duration_seconds?`${a.duration_seconds}s`:'—'}</td>
                  <td><button onClick={()=>toggleAsgMut.mutate(a.id)} style={{ padding:'4px 10px',borderRadius:99,fontSize:12,fontWeight:700,cursor:'pointer',border:'none',background:a.is_active?'var(--success)':'var(--border)',color:a.is_active?'white':'var(--text-muted)'}}>{a.is_active?'● ON':'○ OFF'}</button></td>
                  <td style={{fontSize:12,color:'var(--text-muted)'}}>{fmt.ago(a.created_at)}</td>
                  <td><Button variant="ghost" size="sm" onClick={()=>setDelAsgM(a)}><Trash2 size={13} color="var(--danger)"/></Button></td>
                </tr>
              ))}
              {!assignments.length && <tr key="asg-none"><td colSpan={7}><div className="empty"><div className="empty__icon">📋</div><div className="empty__title">No direct assignments yet</div><p>Create one to assign a file directly to a specific display</p></div></td></tr>}
            </tbody>
          </table>
        </div>
      </Card>
      END DIRECT ASSIGNMENTS UI */}

      <Modal open={pubModal} onClose={()=>setPubModal(false)} title="Publish Content to TVs"
        footer={<>
          <Button variant="secondary" onClick={()=>setPubModal(false)}>Cancel</Button>
          <Button variant="primary" loading={publishMut.isPending||uploading} onClick={handlePublish}>
            {pubTab==='Direct TV Upload'?<><Tv size={14}/> Upload to TV</>:<><Send size={14}/> Publish</>}
          </Button>
        </>}>
        <div className="form-grid">
          <div style={{display:'flex',borderRadius:'var(--radius-sm)',overflow:'hidden',border:'1px solid var(--border)',width:'fit-content'}}>
            {PUB_TABS.map(t=>(
              <button key={t} onClick={()=>{setPubTab(t);setSelFiles([]);setUpFiles([]);setDtFiles([]);}}
                style={{padding:'8px 14px',fontSize:13,fontWeight:600,cursor:'pointer',border:'none',background:pubTab===t?'var(--primary)':'white',color:pubTab===t?'white':'var(--text-body)'}}>
                {t}
              </button>
            ))}
          </div>

          {pubTab==='Direct TV Upload' ? (
            <>
              <div style={{background:'var(--bg-main)',borderRadius:'var(--radius-md)',padding:14}}>
                <div style={{fontWeight:700,fontSize:13,marginBottom:10}}>Target TV</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                  <Field label="Production Line (optional)">
                    <Select value={dtLineId} onChange={e=>{setDtLineId(e.target.value);setDtDispNum('');}}>
                      <option value="">All lines...</option>
                      {lines.map(l=><option key={l.id} value={l.id}>{l.production_line_name}</option>)}
                    </Select>
                  </Field>
                  <Field label="Target Display *">
                    <Select value={dtDispNum} onChange={e=>setDtDispNum(e.target.value)}>
                      <option value="">Select display...</option>
                      {dtDisplays.map(d=><option key={d.id} value={d.display_number}>{d.display_name} ({d.display_number})</option>)}
                    </Select>
                  </Field>
                </div>
              </div>
              {/* FIX: Duration fields also in Direct TV Upload tab */}
              {durationRow}
              <div {...getDtRootProps()} style={{border:`2px dashed ${isDtDrag?'var(--primary)':'var(--border)'}`,borderRadius:'var(--radius-md)',padding:24,textAlign:'center',cursor:'pointer',background:isDtDrag?'var(--primary-10)':'var(--bg-main)'}}>
                <input {...getDtInputProps()}/>
                <div style={{fontSize:32,marginBottom:8}}>📺</div>
                <p style={{fontWeight:600,fontSize:14}}>{isDtDrag?'Drop files...':'Drag files for this TV'}</p>
                <p style={{fontSize:12,color:'var(--text-muted)',marginTop:4}}>Sends directly to TV — not saved to library</p>
              </div>
              {dtFiles.map((f,i)=>(
                <div key={i} style={{display:'flex',alignItems:'center',gap:10,padding:'6px 12px',background:'var(--bg-main)',borderRadius:'var(--radius-sm)',fontSize:13}}>
                  <span>📄</span><span style={{flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{f.name}</span>
                  <span style={{fontSize:12,color:'var(--text-muted)'}}>{(f.size/1024/1024).toFixed(1)}MB</span>
                  <button onClick={()=>setDtFiles(p=>p.filter((_,j)=>j!==i))} style={{color:'var(--danger)',background:'none',border:'none',cursor:'pointer'}}>✕</button>
                </div>
              ))}
              <div style={{background:'#FFF7ED',border:'1px solid var(--warning)',borderRadius:'var(--radius-sm)',padding:'10px 14px',fontSize:12,color:'var(--warning)',display:'flex',gap:8}}>
                <AlertTriangle size={13} style={{flexShrink:0,marginTop:1}}/>
                <span>If this TV has published content from a production line, that takes priority. Unpublish first to see direct uploads.</span>
              </div>
            </>
          ) : (
            <>
              <div style={{background:'var(--bg-main)',borderRadius:'var(--radius-md)',padding:14}}>
                <div style={{fontWeight:700,fontSize:13,marginBottom:10}}>Step 1 — Production Line</div>
                <div style={{display:'flex',gap:8,marginBottom:10}}>
                  {[{v:'one',l:'One Line'},{v:'all',l:'All Lines'}].map(o=>(
                    <button key={o.v} onClick={()=>{setPubLineMode(o.v);setPubLineId('');setPubSelDisps([]);}}
                      style={{padding:'6px 14px',borderRadius:99,fontSize:13,fontWeight:600,cursor:'pointer',border:`1.5px solid ${pubLineMode===o.v?'var(--primary)':'var(--border)'}`,background:pubLineMode===o.v?'var(--primary)':'white',color:pubLineMode===o.v?'white':'var(--text-body)'}}>
                      {o.l}
                    </button>
                  ))}
                </div>
                {pubLineMode==='one' && <Select value={pubLineId} onChange={e=>{setPubLineId(e.target.value);setPubSelDisps([]);}}><option value="">Choose a line...</option>{lines.map(l=><option key={l.id} value={l.id}>{l.production_line_name}</option>)}</Select>}
                {pubLineMode==='all' && <div style={{fontSize:12,color:'var(--text-muted)',fontStyle:'italic'}}>Will publish to ALL active production lines</div>}
              </div>

              {(pubLineMode==='all'||pubLineId) && (
                <div style={{background:'var(--bg-main)',borderRadius:'var(--radius-md)',padding:14}}>
                  <div style={{fontWeight:700,fontSize:13,marginBottom:10}}>Step 2 — Displays</div>
                  <div style={{display:'flex',gap:8,marginBottom:10}}>
                    {[{v:'all',l:'All Displays'},{v:'specific',l:'Specific Displays'}].map(o=>(
                      <button key={o.v} onClick={()=>{setPubDispMode(o.v);setPubSelDisps([]);}}
                        style={{padding:'6px 14px',borderRadius:99,fontSize:13,fontWeight:600,cursor:'pointer',border:`1.5px solid ${pubDispMode===o.v?'var(--primary)':'var(--border)'}`,background:pubDispMode===o.v?'var(--primary)':'white',color:pubDispMode===o.v?'white':'var(--text-body)'}}>
                        {o.l}
                      </button>
                    ))}
                  </div>
                  {pubDispMode==='specific' && (
                    <div style={{display:'flex',flexDirection:'column',gap:6,maxHeight:150,overflowY:'auto'}}>
                      {displaysInLine.map(d=>{
                        const sel=pubSelDisps.includes(d.id);
                        return (<div key={d.id} onClick={()=>toggleDisp(d.id)} style={{display:'flex',alignItems:'center',gap:10,padding:'7px 10px',borderRadius:'var(--radius-sm)',cursor:'pointer',border:`1.5px solid ${sel?'var(--primary)':'var(--border)'}`,background:sel?'var(--primary-10)':'white'}}>
                          <div style={{width:8,height:8,borderRadius:'50%',background:d.status==='ONLINE'?'var(--success)':'var(--danger)',flexShrink:0}}/>
                          <div style={{width:16,height:16,borderRadius:4,border:`2px solid ${sel?'var(--primary)':'var(--border)'}`,background:sel?'var(--primary)':'white',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>{sel&&<span style={{color:'white',fontSize:10,fontWeight:800}}>✓</span>}</div>
                          <Monitor size={12} color="var(--text-muted)"/>
                          <span style={{fontSize:12,fontWeight:600,flex:1}}>{d.display_name}</span>
                          <code style={{fontSize:11,color:'var(--text-muted)'}}>{d.display_number}</code>
                        </div>);
                      })}
                    </div>
                  )}
                </div>
              )}

              <div style={{background:'var(--bg-main)',borderRadius:'var(--radius-md)',padding:14}}>
                <div style={{fontWeight:700,fontSize:13,marginBottom:10}}>Step 3 — Content</div>
                {pubTab==='From Library' ? (
                  <>
                    <Field label="Folder *"><Select value={pubFolder} onChange={e=>{setPubFolder(e.target.value);setSelFiles([]);}}><option value="">Select folder...</option>{folders.map(f=><option key={f.folder_name} value={f.folder_name}>{f.folder_name} ({f.file_count} files)</option>)}</Select></Field>
                    {pubFolder && folderFiles.length>0 && (
                      <div style={{marginTop:10}}>
                        <div style={{display:'flex',justifyContent:'space-between',marginBottom:6}}>
                          <label style={{fontSize:12,fontWeight:600}}>Files <span style={{color:'var(--text-muted)',fontWeight:400}}>(empty = all)</span></label>
                          <button onClick={()=>setSelFiles(selFiles.length===folderFiles.length?[]:folderFiles.map(f=>f.id))} style={{fontSize:12,color:'var(--primary)',fontWeight:600,background:'none',border:'none',cursor:'pointer'}}>{selFiles.length===folderFiles.length?'Deselect all':'Select all'}</button>
                        </div>
                        <div style={{display:'flex',flexDirection:'column',gap:5,maxHeight:160,overflowY:'auto'}}>
                          {folderFiles.map(f=>{const sel=selFiles.includes(f.id);return(<div key={f.id} onClick={()=>toggleFile(f.id)} style={{display:'flex',alignItems:'center',gap:8,padding:'6px 10px',borderRadius:'var(--radius-sm)',cursor:'pointer',border:`1.5px solid ${sel?'var(--primary)':'var(--border)'}`,background:sel?'var(--primary-10)':'white'}}>
                            <div style={{width:15,height:15,borderRadius:3,border:`2px solid ${sel?'var(--primary)':'var(--border)'}`,background:sel?'var(--primary)':'white',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>{sel&&<span style={{color:'white',fontSize:9,fontWeight:800}}>✓</span>}</div>
                            <span style={{fontSize:15}}>{FILE_ICON[f.file_type]||'📄'}</span><span style={{fontSize:12,flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{f.file_name}</span>{isDocType(f.file_name)&&<Badge variant="warning" style={{fontSize:10}}>DOC</Badge>}
                          </div>);})}
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <>
                    <Field label="Save to Folder"><Input placeholder="e.g. promo-july" value={upFolder} onChange={e=>setUpFolder(e.target.value)}/></Field>
                    <div {...getUpRootProps()} style={{border:`2px dashed ${isUpDrag?'var(--primary)':'var(--border)'}`,borderRadius:'var(--radius-md)',padding:20,textAlign:'center',cursor:'pointer',background:isUpDrag?'var(--primary-10)':'white',marginTop:8}}>
                      <input {...getUpInputProps()}/>
                      <div style={{fontSize:28,marginBottom:6}}>📥</div>
                      <p style={{fontWeight:600,fontSize:13}}>{isUpDrag?'Drop files...':'Drag & drop or click'}</p>
                    </div>
                    {upFiles.map((f,i)=>(
                      <div key={i} style={{display:'flex',alignItems:'center',gap:8,padding:'5px 10px',background:'var(--bg-main)',borderRadius:'var(--radius-sm)',fontSize:12}}>
                        <span>📄</span><span style={{flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{f.name}</span>
                        <button onClick={()=>setUpFiles(p=>p.filter((_,j)=>j!==i))} style={{color:'var(--danger)',background:'none',border:'none',cursor:'pointer'}}>✕</button>
                      </div>
                    ))}
                  </>
                )}
              </div>
              {durationRow}
            </>
          )}
        </div>
      </Modal>


      {/* ── PUBLISH HISTORY ── */}
      <Card title="Publish History" subtitle="Re-publish previous content with one click" style={{ marginTop:20 }}>
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Folder</th><th>Line</th><th>TVs</th><th>Duration</th><th>Doc/pg</th><th>Published</th><th></th></tr></thead>
            <tbody>
              {publishHistory.map(h=>(
                <tr key={h.id}>
                  <td><div className="table__name">{h.folder_name}</div></td>
                  <td style={{fontSize:13}}>{h.production_line_name||'All lines'}</td>
                  <td><Badge variant="primary">{h.tv_count} TVs</Badge></td>
                  <td style={{fontSize:12}}>{h.duration}s</td>
                  <td style={{fontSize:12}}>{h.doc_duration}s/pg</td>
                  <td style={{fontSize:12,color:'var(--text-muted)'}}>{fmt.ago(h.created_at)}</td>
                  <td>
                    <Button variant="secondary" size="sm" loading={publishMut.isPending}
                      onClick={()=>{
                        const payload = {
                          folder_name: h.folder_name,
                          duration: h.duration,
                          doc_duration: h.doc_duration,
                        };
                        if (h.all_lines) payload.all_lines = true;
                        else payload.production_line_id = h.production_line_id;
                        if (h.display_ids) try { payload.display_ids = JSON.parse(h.display_ids); } catch {}
                        if (h.file_ids) try { payload.file_ids = JSON.parse(h.file_ids); } catch {}
                        publishMut.mutate(payload);
                      }}>
                      🔄 Re-publish
                    </Button>
                  </td>
                </tr>
              ))}
              {!publishHistory.length && <tr key="ph-none"><td colSpan={7}><div className="empty"><div className="empty__title">No publish history yet</div></div></td></tr>}
            </tbody>
          </table>
        </div>
      </Card>

      <ConfirmModal open={!!delFileM} onClose={()=>setDelFileM(null)} title="Remove File" message={`Remove "${delFileM?.file_name}"?`} loading={delFileMut.isPending} onConfirm={()=>delFileMut.mutate(delFileM.id)}/>
      {/* DELETE ASSIGNMENT CONFIRM — temporarily hidden
      <ConfirmModal open={!!delAsgM}  onClose={()=>setDelAsgM(null)}  title="Delete Assignment" message={`Remove assignment for "${delAsgM?.file_name}" from ${delAsgM?.display_number}?`} loading={delAsgMut.isPending} onConfirm={()=>delAsgMut.mutate(delAsgM.id)}/>
      END DELETE ASSIGNMENT CONFIRM */}

      <FilePreview file={previewFile} open={!!previewFile} onClose={()=>setPreviewFile(null)}/>
    </div>
  );
}